import json
import time
import traceback
from datetime import date, datetime
import schedule

from db import get_connection, ensure_table_exists, registo_existe, existe_registo_para_dia, inserir_registo
from scraper import check as scraper_check

def job_check(cfg):
    url = cfg['site_url']
    ua = cfg.get('user_agent') or 'Mozilla/5.0 (compatible; PromoChecker/1.0)'
    print(f"[{datetime.now()}] Starting check for: {url}")
    try:
        disponivel, promo, validoate, source_url = scraper_check(url, ua)
        today = date.today()
        conn = get_connection(cfg['postgres'])
        ensure_table_exists(conn)

        # se existir uma promoção (disponivel True) e não existir registo igual -> inserir
        if disponivel:
            if not registo_existe(conn, today, True):
                inserir_registo(conn, today, True, promo, validoate, source_url)
                print(f"[{datetime.now()}] Promo encontrada -> {promo} (inserido)")
            else:
                print(f"[{datetime.now()}] Promo encontrada mas já registada hoje.")
        else:
            # se não disponível, garante pelo menos 1 registo por dia com disponivel = False
            if not existe_registo_para_dia(conn, today):
                inserir_registo(conn, today, False, 'INDISPONIVEL', '', source_url)
                print(f"[{datetime.now()}] Não disponível -> inserido registo diário de indisponibilidade.")
            else:
                print(f"[{datetime.now()}] Não disponível e já existe registo para hoje.")

        conn.close()
    except Exception as e:
        print('Erro durante job_check:', e)
        traceback.print_exc()

def load_config(path='config.json'):
    with open(path, 'r') as f:
        return json.load(f)

def main():
    cfg = load_config()

    # schedule times from config (assumes local system timezone matches desired timezone)
    times = cfg.get('check_times', ['10:00', '22:00'])
    for t in times:
        schedule.every().day.at(t).do(job_check, cfg=cfg)
        print(f"Scheduled daily check at {t} local time.")

    # run an immediate check on container start
    job_check(cfg)

    while True:
        schedule.run_pending()
        time.sleep(1)

if __name__ == '__main__':
    main()