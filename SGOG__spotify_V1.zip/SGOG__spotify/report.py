from flask import Flask, render_template, request
import psycopg2
import math

app = Flask(__name__)

# Config BD (ajusta para os teus valores)
DB_CONFIG = {
    "dbname": "spotify",
    "user": "postgres",
    "password": "1234",
    "host": "localhost",
    "port": 5432
}

@app.route('/')
def index():
    page = int(request.args.get('page', 1))
    per_page = 30
    offset = (page - 1) * per_page

    conn = psycopg2.connect(**DB_CONFIG)
    cur = conn.cursor()

    cur.execute("SELECT COUNT(*) FROM spotify_promocoes;")
    total_rows = cur.fetchone()[0]
    total_pages = math.ceil(total_rows / per_page)

    cur.execute("""
        SELECT data, estado 
        FROM spotify_promocoes 
        ORDER BY data DESC 
        LIMIT %s OFFSET %s
    """, (per_page, offset))
    rows = cur.fetchall()

    cur.close()
    conn.close()

    return render_template("report.html",
                           rows=rows,
                           page=page,
                           total_pages=total_pages)

if __name__ == "__main__":
    app.run(host="0.0.0.0", port=8080, debug=True)
