import requests
import re
from bs4 import BeautifulSoup

def _fetch_html(url, user_agent, timeout=15):
    headers = {
        'User-Agent': user_agent
    }
    r = requests.get(url, headers=headers, timeout=timeout)
    r.raise_for_status()
    return r.text

def detect_promo_from_html(html):
    # normalize
    h = html.lower()

    # common promo indicators (portuguese + english)
    patterns = {
        '3_months_free': ['3 meses', '3 months', '3 months free', 'try premium free for 3 months', '3 months of premium'],
        '2_months_free': ['2 meses', '2 months'],
        '1_month_free' : ['1 mês', '1 mes', '1 month', '1 month free'],
        '99_cent'      : ['0,99', '0.99', '99 cent', '99¢', '€0,99', '€0.99']
    }

    disponivel = False
    promo = None

    if any(p in h for p in patterns['3_months_free']):
        disponivel = True
        if any(x in h for x in patterns['99_cent']):
            promo = '3 months - 0.99'
        elif 'free' in h or 'grátis' in h or 'grátis' in h:
            promo = '3 months - free'
        else:
            promo = '3 months - promo'
    elif any(p in h for p in patterns['2_months_free']):
        disponivel = True
        promo = '2 months - free'
    elif any(p in h for p in patterns['1_month_free']):
        disponivel = True
        promo = '1 month - free'
    elif any(p in h for p in patterns['99_cent']):
        disponivel = True
        promo = 'promo 0.99 found'
    else:
        disponivel = False
        promo = 'INDISPONIVEL'

    # try to find an expiration date nearby (best-effort)
    validoate = ''
    try:
        # search for common phrases like 'offer ends', 'oferta termina a', 'válida até'
        m = re.search(r'(offer ends on|offer ends|oferta termina a|válida até|válido até)\s*[:\-]?[\s]*([a-z0-9 ,./-]+)', h)
        if m:
            validoate = m.group(2).split('\n')[0].strip()
    except Exception:
        validoate = ''

    return disponivel, promo, validoate

def verifica_promo_spotify(url, user_agent):
    try:
        html = _fetch_html(url, user_agent)
    except Exception as e:
        return False, f'ERRO: {e}', ''

    return detect_promo_from_html(html), html[:0]  # return structured result and empty source preview

# compatibility wrapper for main.py expected return
def check(url, user_agent):
    res, _ = verifica_promo_spotify(url, user_agent)
    dispo, promo, validoate = res if isinstance(res, tuple) else (False, 'INDISPONIVEL', '')
    return dispo, promo, validoate, url