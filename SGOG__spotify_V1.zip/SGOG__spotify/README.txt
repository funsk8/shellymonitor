Spotify Promo Checker - README
=============================

Conteúdo do pacote: spotify-promo-checker/
- main.py       : script principal que agenda verificações às horas configuradas
- scraper.py    : função que acede ao site do Spotify e detecta promoções
- db.py         : funções para ligação e inserção em PostgreSQL
- config.json   : configuração (site, horários, DB, user-agent)
- requirements.txt
- Dockerfile    : imagem Docker pronta (timezone Europe/Lisbon)
- README.txt    : este ficheiro

Quick start (com Docker):
-------------------------
1) No host (Debian 12 CT com Docker instalado) cria uma network:
   docker network create spotify-net

2) Iniciar o PostgreSQL (exemplo):
   docker run -d --name spotifydb --network spotify-net \
     -e POSTGRES_USER=spotifyuser -e POSTGRES_PASSWORD=sp0tify_pass \
     -e POSTGRES_DB=spotifydb -v spotify_data:/var/lib/postgresql/data postgres:16

3) Build da imagem:
   docker build -t spotify-checker .

4) Run do container:
   docker run -d --name spotify-checker --network spotify-net spotify-checker

Notas:
- O Dockerfile define o timezone para Europe/Lisbon.
- Edita config.json no host antes de build/run se desejares alterar credenciais ou horas.