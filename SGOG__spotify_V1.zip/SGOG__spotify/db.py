import psycopg2
from datetime import date, datetime

def get_connection(cfg):
    return psycopg2.connect(
        host=cfg['host'],
        port=cfg.get('port', 5432),
        database=cfg['database'],
        user=cfg['user'],
        password=cfg['password']
    )

def ensure_table_exists(conn):
    with conn.cursor() as cur:
        cur.execute('''
            CREATE TABLE IF NOT EXISTS spotify_promotions (
                id SERIAL PRIMARY KEY,
                data DATE NOT NULL,
                disponivel BOOLEAN NOT NULL,
                obs TEXT,
                validoate TEXT,
                source_url TEXT,
                created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
            );
        ''')
        conn.commit()

def registo_existe(conn, data_obj, disponivel):
    with conn.cursor() as cur:
        cur.execute("""SELECT COUNT(*) FROM spotify_promotions
                       WHERE data = %s AND disponivel = %s;""", (data_obj, disponivel))
        return cur.fetchone()[0] > 0

def existe_registo_para_dia(conn, data_obj):
    with conn.cursor() as cur:
        cur.execute("""SELECT COUNT(*) FROM spotify_promotions
                       WHERE data = %s;""", (data_obj,))
        return cur.fetchone()[0] > 0

def inserir_registo(conn, data_obj, disponivel, obs, validoate, source_url):
    with conn.cursor() as cur:
        cur.execute("""INSERT INTO spotify_promotions (data, disponivel, obs, validoate, source_url)
                       VALUES (%s, %s, %s, %s, %s);""", (data_obj, disponivel, obs, validoate, source_url))
        conn.commit()