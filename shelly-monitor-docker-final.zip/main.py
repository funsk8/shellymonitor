import streamlit as st
import threading, time, requests, os, csv, json
from datetime import datetime, timedelta
import matplotlib.pyplot as plt
import pandas as pd

CONFIG_FILE = "config.json"
DEFAULT_CONFIG = {
  "SHELLY_IP": "http://192.168.1.100",
  "PRECO_KWH": 0.1544,
  "INTERVALO_ATUALIZACAO": 5,
  "PASTA_DADOS": "dados_shelly",
  "RETENCAO_DIAS": 365
}

os.makedirs("dados_shelly", exist_ok=True)

def read_config():
    try:
        with open(CONFIG_FILE, "r") as f:
            cfg = json.load(f)
    except Exception:
        cfg = DEFAULT_CONFIG.copy()
        with open(CONFIG_FILE, "w") as f:
            json.dump(cfg, f, indent=2)
    for k,v in DEFAULT_CONFIG.items():
        if k not in cfg:
            cfg[k]=v
    return cfg

def save_config(cfg):
    with open(CONFIG_FILE, "w") as f:
        json.dump(cfg, f, indent=2)

def log(msg):
    os.makedirs("dados_shelly", exist_ok=True)
    with open(os.path.join("dados_shelly","logs.txt"), "a") as f:
        f.write(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S')}] {msg}\n")

def day_filename(day):
    return os.path.join("dados_shelly", f"dados_{day}.csv")

def save_reading(day, ts, power, voltage):
    fn = day_filename(day)
    existed = os.path.exists(fn)
    with open(fn, "a", newline="") as f:
        writer = csv.writer(f)
        if not existed:
            writer.writerow(["time","power","voltage"])
        writer.writerow([ts.strftime("%H:%M:%S"), f"{power:.6f}", f"{voltage:.3f}"])

def load_day_csv(day):
    fn = day_filename(day)
    if not os.path.exists(fn):
        return pd.DataFrame(columns=["time","power","voltage"])
    try:
        df = pd.read_csv(fn)
        return df
    except Exception as e:
        log(f"Erro a ler {fn}: {e}")
        return pd.DataFrame(columns=["time","power","voltage"])

def prune_old_files(retention_days):
    cutoff = datetime.now().date() - timedelta(days=retention_days)
    folder = "dados_shelly"
    for name in os.listdir(folder):
        if not name.startswith("dados_") or not name.endswith('.csv'):
            continue
        try:
            datepart = name[len('dados_'):-4]
            filedate = datetime.strptime(datepart, "%Y-%m-%d").date()
            if filedate < cutoff:
                os.remove(os.path.join(folder, name))
                log(f"Removed old file: {name}")
        except Exception:
            continue

state = {
    "last_sample_time": None,
    "last_power": None,
    "daily_import": {},   # { 'YYYY-MM-DD': kWh }
    "daily_export": {}    # { 'YYYY-MM-DD': kWh }
}

def initialize_from_recent_csv():
    for i in range(0,3):
        day = (datetime.now() - timedelta(days=i)).strftime("%Y-%m-%d")
        df = load_day_csv(day)
        imp = 0.0
        exp = 0.0
        last_ts = None
        last_power = None
        for idx, row in df.iterrows():
            try:
                t = datetime.strptime(f"{day} {row['time']}", "%Y-%m-%d %H:%M:%S")
                power = float(row['power'])
                if last_ts is not None and last_power is not None:
                    dt = (t - last_ts).total_seconds()
                    if last_power > 0:
                        imp += last_power * dt / 3600000.0
                    elif last_power < 0:
                        exp += abs(last_power) * dt / 3600000.0
                last_ts = t
                last_power = power
            except Exception:
                continue
        state['daily_import'][day] = imp
        state['daily_export'][day] = exp
        if day == datetime.now().strftime("%Y-%m-%d") and len(df)>0:
            lastrow = df.iloc[-1]
            state['last_sample_time'] = datetime.strptime(f"{day} {lastrow['time']}", "%Y-%m-%d %H:%M:%S")
            state['last_power'] = float(lastrow['power'])

def get_shelly(ip):
    try:
        r = requests.get(f"{ip}/status", timeout=5)
        if r.status_code==200:
            data = r.json()
            em = data.get('emeters', [{}])
            if len(em)>1:
                emeter = em[1]
            elif len(em)>0:
                emeter = em[0]
            else:
                emeter = {}
            power = emeter.get('power', 0.0)
            voltage = emeter.get('voltage', 0.0)
            return float(power), float(voltage)
    except Exception as e:
        log(f"Erro a ligar à Shelly: {e}")
    return None, None

def backend_loop():
    cfg = read_config()
    ip = cfg.get('SHELLY_IP')
    interval = max(1, int(cfg.get('INTERVALO_ATUALIZACAO', 5)))
    retention = int(cfg.get('RETENCAO_DIAS', 365))
    prune_old_files(retention)
    initialize_from_recent_csv()
    while True:
        try:
            cfg = read_config()
            ip = cfg.get('SHELLY_IP')
            interval = max(1, int(cfg.get('INTERVALO_ATUALIZACAO', 5)))
            retention = int(cfg.get('RETENCAO_DIAS', 365))
            prune_old_files(retention)

            power, voltage = get_shelly(ip)
            now = datetime.now()
            day = now.strftime("%Y-%m-%d")

            if power is not None and voltage is not None:
                state['daily_import'].setdefault(day, 0.0)
                state['daily_export'].setdefault(day, 0.0)

                if state['last_sample_time'] is not None and state['last_power'] is not None:
                    dt = (now - state['last_sample_time']).total_seconds()
                    if state['last_power'] > 0:
                        state['daily_import'][day] = state['daily_import'].get(day,0.0) + state['last_power'] * dt / 3600000.0
                    elif state['last_power'] < 0:
                        state['daily_export'][day] = state['daily_export'].get(day,0.0) + abs(state['last_power']) * dt / 3600000.0

                save_reading(day, now, power, voltage)
                state['last_sample_time'] = now
                state['last_power'] = power
                log(f"Sample saved: {day} {now.strftime('%H:%M:%S')} power={power:.2f}V={voltage:.1f}")
            else:
                log("Sample failed (no data)")

        except Exception as e:
            log(f"Backend loop exception: {e}")
        time.sleep(interval)

threading.Thread(target=backend_loop, daemon=True).start()

st.set_page_config(page_title="Shelly Monitor", layout="wide")
st.title("Shelly Monitor - Web UI")

cfg = read_config()
try:
    refresh_ms = int(cfg.get('INTERVALO_ATUALIZACAO',5)) * 1000
except Exception:
    refresh_ms = 5000

tabs = st.tabs(["🏠 Tempo Real", "📅 Histórico", "⚙️ Configuração"])

with tabs[0]:
    st.subheader("Visão do dia atual (00:00 -> 23:59:59)")
    st.write(f"Última leitura processada: {state.get('last_sample_time')}")
    # autorefresh (uses streamlit-autorefresh)
    try:
        from streamlit_autorefresh import st_autorefresh as s_ar
        s_ar(interval=refresh_ms, key="auto_refresh")
    except Exception:
        pass

    today = datetime.now().strftime("%Y-%m-%d")
    df_today = load_day_csv(today)
    if not df_today.empty:
        df_today['seconds'] = df_today['time'].apply(lambda t: int(t.split(':')[0])*3600 + int(t.split(':')[1])*60 + int(t.split(':')[2]))
        df_today['minute_decimal'] = df_today['seconds'] / 60.0
        df_today['power'] = pd.to_numeric(df_today['power'], errors='coerce').fillna(0.0)

    fig, ax = plt.subplots(figsize=(10,4.5))
    ax.axhline(0, color='black', linestyle='--', linewidth=1.2)
    if df_today.empty:
        ax.set_title('Sem dados de hoje')
    else:
        x = df_today['minute_decimal'].tolist()
        y = df_today['power'].tolist()
        pos_x = [xx for xx, yy in zip(x,y) if yy >= 0]
        pos_y = [yy for yy in y if yy >= 0]
        neg_x = [xx for xx, yy in zip(x,y) if yy < 0]
        neg_y = [yy for yy in y if yy < 0]
        ax.axhspan(-2000, 2000, color='gray', alpha=0.08)
        ax.scatter(pos_x, pos_y, marker='o', label='Consumo (W)')
        ax.scatter(neg_x, neg_y, marker='o', label='Exportação (W)')
        ymax = max(max(y), 2000)
        ymin = min(min(y), -2000)
        ymax = ((ymax + 299) // 300) * 300
        ymin = ((ymin - 299) // 300) * 300
        ax.set_ylim(ymin, ymax)
        ax.set_yticks(range(int(ymin), int(ymax)+1, 300))
        ax.set_xlim(0, 1440)
        ax.set_xticks(range(0,1441,60))
        ax.set_xticklabels([f\"{h}h\" for h in range(0,25)])
        ax.set_xlabel('Hora do dia')
        ax.set_ylabel('Potência (W)')
        ax.set_title('Histórico de Potência - Hoje')
        ax.legend(loc='upper right')
    st.pyplot(fig)

    today_imp = state['daily_import'].get(today, 0.0)
    today_exp = state['daily_export'].get(today, 0.0)
    preco = cfg.get('PRECO_KWH', 0.1544)
    st.metric('Importado (kWh)', f\"{today_imp:.3f}\")
    st.metric('Exportado (kWh)', f\"{today_exp:.3f}\")
    st.write(f\"Custo estimado (importado) = {today_imp:.3f} kWh × {preco:.4f} €/kWh = {today_imp*preco:.2f} €\")

with tabs[1]:
    st.subheader('Histórico de dias anteriores')
    files = []
    for name in os.listdir('dados_shelly'):
        if name.startswith('dados_') and name.endswith('.csv'):
            try:
                datepart = name[len('dados_'):-4]
                _ = datetime.strptime(datepart, '%Y-%m-%d')
                files.append(datepart)
            except Exception:
                continue
    files = sorted(files, reverse=True)
    if not files:
        st.write('Sem ficheiros históricos ainda.')
    else:
        sel = st.selectbox('Escolhe uma data', options=files, index=0)
        df = load_day_csv(sel)
        if df.empty:
            st.write('Sem dados para esse dia.')
        else:
            df['seconds'] = df['time'].apply(lambda t: int(t.split(':')[0])*3600 + int(t.split(':')[1])*60 + int(t.split(':')[2]))
            df['minute_decimal'] = df['seconds'] / 60.0
            df['power'] = pd.to_numeric(df['power'], errors='coerce').fillna(0.0)
            fig2, ax2 = plt.subplots(figsize=(10,4.5))
            ax2.axhline(0, color='black', linestyle='--', linewidth=1.2)
            x = df['minute_decimal'].tolist()
            y = df['power'].tolist()
            pos_x = [xx for xx, yy in zip(x,y) if yy >= 0]
            pos_y = [yy for yy in y if yy >= 0]
            neg_x = [xx for xx, yy in zip(x,y) if yy < 0]
            neg_y = [yy for yy in y if yy < 0]
            ax2.scatter(pos_x, pos_y, marker='o', label='Consumo (W)')
            ax2.scatter(neg_x, neg_y, marker='o', label='Exportação (W)')
            ymax = max(max(y), 2000)
            ymin = min(min(y), -2000)
            ymax = ((ymax + 299) // 300) * 300
            ymin = ((ymin - 299) // 300) * 300
            ax2.set_ylim(ymin, ymax)
            ax2.set_yticks(range(int(ymin), int(ymax)+1, 300))
            ax2.set_xlim(0, 1440)
            ax2.set_xticks(range(0,1441,60))
            ax2.set_xticklabels([f\"{h}h\" for h in range(0,25)])
            ax2.set_xlabel('Hora do dia')
            ax2.set_ylabel('Potência (W)')
            ax2.set_title(f'Histórico de Potência - {sel}')
            ax2.legend(loc='upper right')
            st.pyplot(fig2)

            imp = 0.0
            exp = 0.0
            last_ts = None
            last_p = None
            for idx,row in df.iterrows():
                try:
                    t = datetime.strptime(f\"{sel} {row['time']}\", \"%Y-%m-%d %H:%M:%S\")
                    p = float(row['power'])
                    if last_ts is not None and last_p is not None:
                        dt = (t - last_ts).total_seconds()
                        if last_p > 0:
                            imp += last_p * dt / 3600000.0
                        elif last_p < 0:
                            exp += abs(last_p) * dt / 3600000.0
                    last_ts = t
                    last_p = p
                except Exception:
                    continue
            st.write(f\"Importado: {imp:.3f} kWh  |  Exportado: {exp:.3f} kWh\")
            st.write(f\"Custo estimado (importado): {imp:.3f} kWh × {cfg.get('PRECO_KWH'):.4f} €/kWh = {imp*cfg.get('PRECO_KWH'):.2f} €\")

with tabs[2]:
    st.subheader('Configuração do sistema')
    cfg = read_config()
    shelly_ip = st.text_input('IP da Shelly (inclui http://)', value=cfg.get('SHELLY_IP',''))
    preco_kwh = st.number_input('Preço por kWh (€)', value=float(cfg.get('PRECO_KWH',0.1544)))
    intervalo = st.number_input('Intervalo de atualização (segundos)', value=int(cfg.get('INTERVALO_ATUALIZACAO',5)), min_value=1)
    retencao = st.number_input('Retenção de ficheiros (dias)', value=int(cfg.get('RETENCAO_DIAS',365)), min_value=1)
    if st.button('💾 Guardar alterações'):
        cfg['SHELLY_IP']=shelly_ip
        cfg['PRECO_KWH']=float(preco_kwh)
        cfg['INTERVALO_ATUALIZACAO']=int(intervalo)
        cfg['RETENCAO_DIAS']=int(retencao)
        save_config(cfg)
        log('Config updated via web UI')
        st.success('Configurações guardadas com sucesso.')

    st.markdown('---')
    st.subheader('Logs recentes')
    logpath = os.path.join('dados_shelly','logs.txt')
    if os.path.exists(logpath):
        with open(logpath,'r') as f:
            logs = f.read().splitlines()[-500:]
        st.text_area('Logs', '\\n'.join(logs), height=300)
    else:
        st.write('Sem logs ainda.')
