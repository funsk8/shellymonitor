Shelly Monitor - Dockerized Streamlit app
----------------------------------------
This package runs a background thread that polls a Shelly EM device and saves one CSV file per day
(dados_YYYY-MM-DD.csv) into /app/dados_shelly. It also exposes a Streamlit web UI on port 8501 with three tabs:
  - Dashboard (real-time view for today 00:00:00 - 23:59:59)
  - Histórico (pick a date to view past days)
  - Config (edit and save config.json directly)

Build and run (example):
  docker build -t shelly-monitor .
  docker run -d -p 8501:8501 -v $(pwd)/dados_shelly:/app/dados_shelly --name shelly-monitor shelly-monitor

Notes:
  - The polling interval, Shelly IP and price per kWh are configurable in config.json or via the Config tab.
  - Files older than RETENCAO_DIAS are deleted automatically.
